package com.example.tictactoepackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    private GameController game;
    private TextView Player1Text;
    private TextView Player2Text;
    private TextView YourText;
    private ImageView Image1;
    private ImageView Image2;
    private ImageView Image3;
    private ImageView Image4;
    private ImageView Image5;
    private ImageView Image6;
    private ImageView Image7;
    private ImageView Image8;
    private ImageView Image9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);
        Intent intent = getIntent();
        String Player1Name = intent.getExtras().getString("Name");
        String Player2Name = intent.getExtras().getString("Name2");
        String fName = intent.getStringExtra("Name");
        YourText = findViewById(R.id.textView3);
        YourText.setText(fName);
        Player1Text = findViewById(R.id.Player1TextID);
        Player2Text = findViewById(R.id.Player2TextID);
        Player1Text.setText(intent.getExtras().getString("Name"));
        Player2Text.setText(intent.getExtras().getString("Name2"));

        Image1 = findViewById(R.id.ImageView1Pic);
        Image2 = findViewById(R.id.ImageView2Pic);
        Image3 = findViewById(R.id.ImageView3Pic);
        Image4 = findViewById(R.id.ImageView4Pic);
        Image5 = findViewById(R.id.ImageView5Pic);
        Image6 = findViewById(R.id.ImageView6Pic);
        Image7 = findViewById(R.id.ImageView7Pic);
        Image8 = findViewById(R.id.ImageView8Pic);
        Image9 = findViewById(R.id.ImageView9Pic);
    }

    public void clickImage(View view){
        ImageView image = (ImageView) view;
        // btn.setText("X");
        image.setEnabled(false);
        // btn.setBackgroundColor(Color.rgb(10,30,50));
    }

    public void SendReply(View v){
        Intent data = new Intent();
        data.putExtra("Answer", "my answer");
        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK) {
            String reply = data.getExtras().getString("Answer");
            // ResultText.setText(reply);
        }
    }

    public void moveToScreen3(View view) {
        Intent intent = new Intent(this, Screen3.class);
        intent.putExtra("Name", "");
        startActivityForResult(intent, 11);
        // startActivity(intent);
    }
}