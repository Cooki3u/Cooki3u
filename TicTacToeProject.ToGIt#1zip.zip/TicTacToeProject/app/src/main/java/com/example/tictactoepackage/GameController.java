package com.example.tictactoepackage;

public class GameController {

    private TicTacToe model;

    // turn = 0 || turn = 1
    private String turn;

    public String setMove(int location){
        model.setMove(location, turn);
        this.turn = String.valueOf(((Integer.parseInt(turn) + 1) % 2));
        return turn;
    }

    public boolean gameOver(){
        return model.gameOver();
    }

    public String getWinner(){
        return model.getWinner();
    }

    public void newGame(){
        turn = "0";
        model.newGame();
    }

}
