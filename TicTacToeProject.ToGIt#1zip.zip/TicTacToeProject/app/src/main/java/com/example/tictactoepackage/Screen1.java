package com.example.tictactoepackage;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Screen1 extends AppCompatActivity {

    private TextView Player1ToIntent;
    private TextView Player2ToIntent;
    private String Name1;
    private String Name2;
    private TextView ResultText;
    private Button MoveToScreen2;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen1);
        Player1ToIntent = findViewById(R.id.FirstPlayerText);
        Player2ToIntent = findViewById(R.id.SecondPlayerText);
        Name1 = Player1ToIntent.getText().toString();
        Name2 = Player2ToIntent.getText().toString();
        // text1 = findViewById(R.id.textView2);
        ResultText = findViewById(R.id.ResultText);
        MoveToScreen2 = findViewById(R.id.button);
    }

    public void MoveToScreen2(View view) {
        intent = new Intent(this, Screen2.class);
        intent.putExtra("Name1", Name1);
        intent.putExtra("Name2", Name2);
        // startActivityForResult(intent, 10);
        startActivity(intent);
    }


}