package com.example.tictactoepackage;

public class TicTacToe {

    private String[][] board;
    private String winner;

    public TicTacToe(String[][] board, String winner){
        this.board = board;
        this.winner = winner;
    }

    public void newGame(){
        board = new String[3][3];
    }

    public String setMove(int location, String player){
        if(location >= 0 && location <= 2) board[0][location % 3] = player;
        if(location >= 3 && location <= 5) board[1][location % 3] = player;
        if(location >= 6 && location <= 8) board[2][location % 3] = player;
        return player;
    }

    public boolean gameOver(){
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++){
                if(board[i][0].equals(board[i][1]) && board[i][1].equals(board[i][2])){
                    winner = board[i][0];
                    return true;
                }
                if(board[0][j].equals(board[1][j]) && board[1][j].equals(board[2][j])){
                    winner = board[0][j];
                    return true;
                }
                if((board[0][0].equals(board[1][1]) && board[1][1].equals(board[2][2])) || (board[0][2].equals(board[1][1]) && board[1][1].equals(board[2][0]))) {
                    winner = board[1][1];
                    return true;
                }
            }
        }
        return false;
    }

    public String getWinner(){
        return winner;
    }



}
