package com.example.tictactoepackage;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Screen3 extends AppCompatActivity {

    private TextView YourText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
        String fName = intent.getStringExtra("Name");
        YourText = findViewById(R.id.textView3);
        YourText.setText(fName);
    }

    public void SendReply(View v){
        Intent data = new Intent();
        data.putExtra("Answer", "my answer");
        setResult(RESULT_OK, data);
        finish();
    }
}