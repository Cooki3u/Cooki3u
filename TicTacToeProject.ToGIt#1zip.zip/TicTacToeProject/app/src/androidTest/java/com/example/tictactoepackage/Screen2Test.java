package com.example.tictactoepackage;

import junit.framework.TestCase;

public class Screen2Test extends TestCase {

}